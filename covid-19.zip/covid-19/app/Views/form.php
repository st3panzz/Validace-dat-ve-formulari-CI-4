<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Covid-19</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
  <div class="container mt-5">
    <?php $validation = \Config\Services::validation(); ?>
      
    <form method="post" action="<?php echo base_url("/validation"); ?>">
        
      <div class="form-group">
        <label>Jméno:</label>
        <input type="text" name="jmeno" class="form-control">

        <?php if($validation->getError('jmeno')) {?>
        
            <div class='alert alert-danger mt-2'>
              <?= $error = $validation->getError('jmeno'); ?>
            </div>
        
        <?php }?>
      </div>
       
      <div class="form-group">
        <label>Příjmení:</label>
        <input type="text" name="prijmeni" class="form-control">

        <?php if($validation->getError('prijmeni')) {?>
        
            <div class='alert alert-danger mt-2'>
              <?= $error = $validation->getError('prijmeni'); ?>
            </div>
        
        <?php }?>
      </div>

      <div class="form-group">
        <label>Kód:</label>
        <input type="text" name="kod" class="form-control">

        <?php if($validation->getError('kod')) {?>
        
            <div class='alert alert-danger mt-2'>
              <?= $error = $validation->getError('kod'); ?>
            </div>
        
        <?php }?>
      </div>
        
      <div class="form-group">   
        <label>Očkování:</label>
                <select name="ockovani"  class="form-control">
                    <option value="0"></option>
                    <option value="1">Pfizer/Biontech</option>
                    <option value="2">AstraZeneca</option>
                    <option value="3">Moderna</option>
                </select>
      </div>
                <div class="form-group">
                       <button type="submit" class="btn btn-primary btn-block">Zaregistrovat se</button>
                </div>
         </div>
      </div>
    </form>
  </div> 
</body>
</html>