<?php

namespace App\Controllers;
use App\Models\Model_form;
use CodeIgniter\Controller;

class Form extends BaseController
{
    public function form() {
        return view('form');
    }
 
    public function validation() {
        helper(['form', 'url']);
        
        $input = $this->validate([
                    'jmeno'			=>	'required',
		    'prijmeni'		        =>	'required|min_length[2]',
		    'kod'	                =>	'required|numeric|max_length[8]',
        ]);
        
        $Model_form = new Model_form();
 
        if (!$input) {
            echo view('form', [
                'validation' => $this->validator
        ]);
            
        } else {
            $Model_form->save([
                    "jmeno"     =>$this->request->getVar("jmeno"),  
                    "prijmeni"  =>$this->request->getVar("prijmeni"),
                    "kod"      =>$this->request->getVar("kod"),
                    "ockovani"  =>$this->request->getVar("ockovani"),
            ]);          
            return $this->response->redirect(site_url('Form/validation'));
        }
    }
}